"""Configuration defaults and validation independent of Blender."""
from __future__ import annotations

from typing import Any, Dict, List

from .constants import QUALITY_LEVELS, SUPPORTED_FORMATS
from .errors import ValidationError
from ..utils import validation


def default_config() -> Dict[str, Any]:
    """Return safe defaults used by preferences and tests."""
    return {
        "provider": "mock",
        "base_url": "http://127.0.0.1:8000",
        "api_key": "",
        "api_key_env": "",
        "model": "default",
        "quality": "standard",
        "output_format": "glb",
        "cache_dir": "",
        "timeout": 60.0,
        "poll_interval": 2.0,
        "job_timeout": 900.0,
        "debug": False,
        "auto_import": True,
        "auto_center": True,
        "auto_scale": True,
        "generate_materials": True,
        "generate_textures": True,
        "max_asset_size_mb": 512,
    }


def validate_config(config: Dict[str, Any]) -> List[str]:
    """Return human-readable configuration errors without raising."""
    errors: List[str] = []
    provider = str(config.get("provider", ""))
    if not provider:
        errors.append("Choose a generation provider.")
    prompt = config.get("prompt", None)
    if prompt is not None and not str(prompt).strip():
        errors.append("Prompt cannot be empty.")
    quality = str(config.get("quality", "standard"))
    if quality not in QUALITY_LEVELS:
        errors.append("Quality must be Draft, Standard, or High.")
    output_format = str(config.get("output_format", "glb")).lower().lstrip(".")
    if output_format not in SUPPORTED_FORMATS:
        errors.append("Output format is not supported.")
    polygon_target = config.get("polygon_target", 50000)
    try:
        if not 100 <= int(polygon_target) <= 10_000_000:
            errors.append("Polygon target must be between 100 and 10,000,000.")
    except (TypeError, ValueError):
        errors.append("Polygon target must be a whole number.")
    for key in ("timeout", "poll_interval", "job_timeout"):
        try:
            if float(config.get(key, 0)) <= 0:
                errors.append(f"{key} must be greater than zero.")
        except (TypeError, ValueError):
            errors.append(f"{key} must be a number.")
    if provider not in {"mock", "local_api", "custom_api"}:
        return
    if provider != "mock":
        try:
            validation.validate_http_url(str(config.get("base_url", "")), "API Base URL")
        except ValidationError as exc:
            errors.append(exc.user_message())
    return errors


def require_valid_config(config: Dict[str, Any]) -> None:
    """Raise one configuration error when validation fails."""
    errors = validate_config(config)
    if errors:
        raise ValidationError("; ".join(errors))
