"""Small, serializable domain models shared by services and providers."""
from __future__ import annotations

from dataclasses import MISSING, asdict, dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class GenerationRequest:
    prompt: str
    negative_prompt: str = ""
    quality: str = "standard"
    output_format: str = "glb"
    style: str = "realistic"
    polygon_target: int = 50000
    generate_materials: bool = True
    generate_textures: bool = True

    def to_dict(self) -> Dict[str, Any]:
        """Return provider payload fields; never include credentials."""
        return {
            "prompt": self.prompt,
            "negative_prompt": self.negative_prompt,
            "quality": self.quality,
            "output_format": self.output_format,
            "style": self.style,
            "polygon_target": self.polygon_target,
            "generate_materials": self.generate_materials,
            "generate_textures": self.generate_textures,
        }


@dataclass
class ProviderConfig:
    base_url: str = "http://127.0.0.1:8000"
    api_key: str = ""
    api_key_env: str = ""
    requires_api_key: bool = False
    model: str = "default"
    timeout: float = 60.0
    generate_path: str = "/generate"
    status_path: str = "/jobs/{job_id}"
    cancel_path: str = "/jobs/{job_id}/cancel"
    download_path: str = ""
    auth_header: str = "Authorization"
    auth_prefix: str = "Bearer "
    headers: Dict[str, str] = field(default_factory=dict)
    request_payload: Dict[str, Any] = field(default_factory=dict)
    job_id_path: str = "id"
    status_path_value: str = "status"
    progress_path: str = "progress"
    output_url_path: str = "download_url"
    error_path: str = "error"
    max_asset_size_mb: int = 512
    poll_interval: float = 2.0
    job_timeout: float = 900.0
    download_host_allowlist: List[str] = field(default_factory=list)

    def public_dict(self) -> Dict[str, Any]:
        """Return non-secret configuration for diagnostics."""
        result = asdict(self)
        result.pop("api_key", None)
        result["headers"] = {key: "<redacted>" for key in self.headers}
        return result


@dataclass
class JobHandle:
    job_id: str
    provider: str
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class JobStatus:
    state: str
    progress: float = 0.0
    message: str = ""
    output_url: Optional[str] = None
    error: Optional[str] = None
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HistoryEntry:
    job_id: str
    timestamp: str
    prompt: str
    negative_prompt: str
    provider: str
    model: str
    quality: str
    output_format: str
    file_path: str
    status: str
    error: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "HistoryEntry":
        if not isinstance(value, dict):
            raise TypeError("History entry must be an object")
        defaults: Dict[str, Any] = {}
        for field_name, field_info in cls.__dataclass_fields__.items():
            if field_info.default is not MISSING:
                defaults[field_name] = field_info.default
            elif field_info.default_factory is not MISSING:
                defaults[field_name] = field_info.default_factory()
            else:
                defaults[field_name] = ""
        return cls(**{key: value.get(key, default) for key, default in defaults.items()})


@dataclass
class ImportResult:
    file_path: str
    object_names: List[str] = field(default_factory=list)
    collection_name: str = ""
    root_object: str = ""
    imported_count: int = 0
    materials: List[str] = field(default_factory=list)
    warning: str = ""


@dataclass
class GenerationResult:
    job_id: str
    status: str
    file_path: str = ""
    message: str = ""
    error: str = ""
    import_result: Optional[ImportResult] = None
