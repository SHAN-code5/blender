"""Service layer exports that do not require Blender at import time.

Blender-only import/post-processing modules are intentionally not imported here
so the provider, validation, download, and job code can be tested headlessly.
"""
from .download_manager import DownloadManager, DownloadedAsset
from .history import read_history, write_history
from .job_manager import JobManager, JobSnapshot

__all__ = [
    "DownloadManager",
    "DownloadedAsset",
    "JobManager",
    "JobSnapshot",
    "read_history",
    "write_history",
]
