"""Persistent, bounded local history with no credentials."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, List

from ..core.constants import HISTORY_FILENAME
from ..core.models import HistoryEntry
from ..utils.files import atomic_write_bytes, ensure_directory

MAX_HISTORY_ENTRIES = 100


def read_history(path: Path) -> List[HistoryEntry]:
    """Read valid history entries, ignoring corrupt or unsupported rows."""
    if not path.exists():
        return []
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return []
    if not isinstance(value, list):
        return []
    entries: List[HistoryEntry] = []
    for row in value[-MAX_HISTORY_ENTRIES:]:
        if not isinstance(row, dict) or not isinstance(row.get("job_id"), str):
            continue
        if any(key in row for key in ("api_key", "authorization", "token", "secret", "password", "credential")):
            continue
        try:
            entry = HistoryEntry.from_dict(row)
            if not entry.prompt or not entry.provider or not entry.status:
                continue
            entries.append(entry)
        except (TypeError, ValueError):
            continue
    return entries


def write_history(path: Path, entries: Iterable[HistoryEntry]) -> Path:
    """Atomically persist a bounded, JSON-serializable history."""
    path = Path(path)
    ensure_directory(path.parent)
    rows = [entry.to_dict() for entry in list(entries)[-MAX_HISTORY_ENTRIES:]]
    data = json.dumps(rows, indent=2, ensure_ascii=False).encode("utf-8")
    return atomic_write_bytes(path, data)


def make_entry(
    *,
    job_id: str,
    prompt: str,
    negative_prompt: str,
    provider: str,
    model: str,
    quality: str,
    output_format: str,
    file_path: str = "",
    status: str = "queued",
    error: str = "",
) -> HistoryEntry:
    """Create a history entry with an ISO timestamp and no secrets."""
    return HistoryEntry(
        job_id=job_id,
        timestamp=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        prompt=prompt,
        negative_prompt=negative_prompt,
        provider=provider,
        model=model,
        quality=quality,
        output_format=output_format,
        file_path=file_path,
        status=status,
        error=error,
    )


def default_history_path(cache_dir: Path) -> Path:
    return Path(cache_dir) / HISTORY_FILENAME
