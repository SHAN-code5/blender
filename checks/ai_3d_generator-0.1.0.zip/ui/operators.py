"""Blender operators and the single timer-driven job coordinator.

The coordinator is module state, not a worker thread. Blender's timer callback
updates the scene property and then optionally imports the downloaded asset on
the main thread. This avoids the unsafe pattern of touching bpy.data from a
network thread.
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

import bpy
from bpy.props import BoolProperty, IntProperty, StringProperty
from bpy.types import Operator

from ..core.config import validate_config
from ..core.constants import STATUS_COMPLETED
from ..core.errors import AI3DError, ImportError_
from ..core.logging import get_logger
from ..core.models import GenerationRequest, ProviderConfig
from ..providers.registry import get_provider_class
from ..services.history import make_entry, read_history, write_history
from ..services.job_manager import JobManager, JobSnapshot
from ..services.download_manager import DownloadManager
from ..utils.files import ensure_directory
from .properties import _provider_config_from_props
from .runtime import provider_config_from_preferences


class _Coordinator:
    def __init__(self) -> None:
        self.job: Optional[JobManager] = None
        self.timer: Optional[Any] = None
        self.request: Optional[Dict[str, Any]] = None
        self.log_path: Optional[Path] = None


COORDINATOR = _Coordinator()


def _scene_props(context: Any) -> Any:
    return context.scene.ai3d


def _load_history_into_props(context: Any) -> None:
    props = _scene_props(context)
    rows = read_history(_history_path(props))
    props.history.clear()
    for item in rows[-20:]:
        row = props.history.add()
        for key, value in item.to_dict().items():
            if hasattr(row, key):
                setattr(row, key, str(value))


def _cache_dir(props: Any) -> Path:
    configured = str(getattr(props, "cache_dir", "") or "").strip()
    if configured:
        return ensure_directory(configured)
    return Path(tempfile.gettempdir()) / "ai_3d_generator"


def _history_path(props: Any) -> Path:
    return _cache_dir(props) / "history.json"


def _request_from_props(props: Any) -> GenerationRequest:
    return GenerationRequest(
        prompt=props.prompt.strip(),
        negative_prompt=props.negative_prompt.strip(),
        quality=props.quality,
        output_format=props.output_format.lower(),
        style=props.style.strip() or "realistic",
        polygon_target=props.polygon_target,
        generate_materials=props.generate_materials,
        generate_textures=props.generate_textures,
    )


def _config_from_props(props: Any) -> ProviderConfig:
    return _provider_config_from_props(props)


def _runtime_config(context: Any, props: Any) -> ProviderConfig:
    return provider_config_from_preferences(context, props)


def _validate_props(props: Any) -> None:
    values = _request_from_props(props).to_dict()
    values.update({
        "provider": props.provider,
        "base_url": props.api_base_url,
        "timeout": props.timeout,
        "poll_interval": props.poll_interval,
        "job_timeout": props.job_timeout,
    })
    errors = validate_config(values)
    if errors:
        raise AI3DError("; ".join(errors))


def _import_downloaded(context: Any, path: str) -> Any:
    props = _scene_props(context)
    if not props.auto_import or not path:
        return
    try:
        from ..services.import_manager import ImportManager, ImportOptions
    except Exception as exc:
        raise AI3DError("The completed asset could not be prepared for Blender import.", detail=str(exc)) from exc

    options = ImportOptions(
        location_mode=props.location_mode,
        auto_center=props.auto_center,
        auto_scale=props.auto_scale,
        smooth_shading=props.smooth_shading,
        recalculate_normals=True,
    )
    import_result = ImportManager(context).import_asset(path, Path(path).suffix, options)
    props.status = "3D asset generated and imported successfully."
    return import_result


def _add_history(context: Any, job_id: str, request: GenerationRequest, file_path: str, status: str, error: str = "") -> None:
    props = _scene_props(context)
    path = _history_path(props)
    rows = read_history(path)
    entry = make_entry(
        job_id=job_id,
        prompt=request.prompt,
        negative_prompt=request.negative_prompt,
        provider=props.provider,
        model=props.model,
        quality=props.quality,
        output_format=request.output_format,
        file_path=file_path,
        status=status,
        error=error,
    )
    rows.append(entry)
    write_history(path, rows)
    props.history.clear()
    for item in rows[-20:]:
        row = props.history.add()
        for key, value in item.to_dict().items():
            if hasattr(row, key):
                setattr(row, key, str(value))


class AI3D_OT_generate(Operator):
    bl_idname = "ai3d.generate"
    bl_label = "Generate 3D"
    bl_description = "Submit the current prompt to the selected provider"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Any) -> set[str]:
        props = _scene_props(context)
        if props.timer_running:
            self.report({'WARNING'}, "A generation job is already running.")
            return {'CANCELLED'}
        try:
            _validate_props(props)
            request = _request_from_props(props)
            provider_cls = get_provider_class(props.provider)
            config = _runtime_config(context, props)
            provider = provider_cls(config)
            manager = DownloadManager(
                _cache_dir(props),
                timeout=props.timeout,
                max_size_mb=props.max_asset_size_mb,
                allowed_hosts=config.download_host_allowlist,
            )
            COORDINATOR.request = request.to_dict()
            COORDINATOR.log_path = _cache_dir(props) / "logs" / "ai3d.log"
            get_logger(COORDINATOR.log_path, debug=props.debug_mode)
            COORDINATOR.job = JobManager(
                provider,
                manager,
                job_timeout=props.job_timeout,
                on_update=lambda snapshot: _on_update(context, snapshot),
                on_finished=lambda result, snapshot: _on_finished(context, result, snapshot),
            )
            COORDINATOR.job.start(COORDINATOR.request)
            props.timer_running = not COORDINATOR.job.snapshot.is_finished
            if props.timer_running:
                props.status = COORDINATOR.job.snapshot.message
                COORDINATOR.timer = bpy.app.timers.register(_timer_callback, first_interval=props.poll_interval)
            return {'FINISHED'}
        except (AI3DError, ValueError, OSError) as exc:
            message = exc.user_message() if isinstance(exc, AI3DError) else str(exc)
            props.status = "Generation failed."
            props.error_message = message
            self.report({'ERROR'}, message)
            return {'CANCELLED'}


class AI3D_OT_cancel(Operator):
    bl_idname = "ai3d.cancel"
    bl_label = "Cancel Generation"
    bl_description = "Cancel the active provider job"
    bl_options = {'REGISTER'}

    def execute(self, context: Any) -> set[str]:
        if COORDINATOR.job:
            COORDINATOR.job.cancel()
        return {'FINISHED'}


class AI3D_OT_retry(Operator):
    bl_idname = "ai3d.retry"
    bl_label = "Retry Generation"
    bl_description = "Retry the selected history entry using its saved prompt"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(name="Index", default=-1)

    def execute(self, context: Any) -> set[str]:
        props = _scene_props(context)
        _load_history_into_props(context)
        index = self.index
        if index < 0 or index >= len(props.history):
            self.report({'ERROR'}, "Select a history entry to retry.")
            return {'CANCELLED'}
        item = props.history[index]
        props.prompt = item.prompt
        props.negative_prompt = getattr(item, "negative_prompt", "")
        props.provider = item.provider
        props.model = item.model
        props.quality = item.quality
        props.output_format = item.output_format.lower()
        return bpy.ops.ai3d.generate()


class AI3D_OT_import(Operator):
    bl_idname = "ai3d.import"
    bl_label = "Import Generated Asset"
    bl_description = "Import the last downloaded generated asset"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(name="File", default="", subtype='FILE_PATH')

    def execute(self, context: Any) -> set[str]:
        props = _scene_props(context)
        path = self.filepath or props.output_path
        if not path:
            self.report({'ERROR'}, "Generate or choose an asset first.")
            return {'CANCELLED'}
        try:
            _import_downloaded(context, path)
            props.status = "3D asset generated and imported successfully."
            return {'FINISHED'}
        except (AI3DError, ImportError_, ValueError) as exc:
            props.error_message = exc.user_message() if isinstance(exc, (AI3DError, ImportError_)) else str(exc)
            self.report({'ERROR'}, props.error_message)
            return {'CANCELLED'}


class AI3D_OT_delete_history_entry(Operator):
    bl_idname = "ai3d.delete_history_entry"
    bl_label = "Delete History Entry"
    bl_description = "Delete one history entry without deleting its downloaded asset"
    bl_options = {'REGISTER'}

    index: IntProperty(name="Index", default=-1)

    def execute(self, context: Any) -> set[str]:
        props = _scene_props(context)
        _load_history_into_props(context)
        path = _history_path(props)
        rows = read_history(path)
        if self.index < 0 or self.index >= len(rows):
            return {'CANCELLED'}
        rows.pop(self.index)
        write_history(path, rows)
        props.history.clear()
        for item in rows[-20:]:
            row = props.history.add()
            for key, value in item.to_dict().items():
                if hasattr(row, key):
                    setattr(row, key, str(value))
        return {'FINISHED'}


class AI3D_OT_clear_history(Operator):
    bl_idname = "ai3d.clear_history"
    bl_label = "Clear History"
    bl_description = "Delete local generation history without deleting generated files"
    bl_options = {'REGISTER'}

    confirm: BoolProperty(name="Confirm", default=False)

    def execute(self, context: Any) -> set[str]:
        props = _scene_props(context)
        props.history.clear()
        path = _history_path(props)
        try:
            path.unlink(missing_ok=True)
        except OSError as exc:
            self.report({'ERROR'}, f"Could not clear history: {exc}")
            return {'CANCELLED'}
        return {'FINISHED'}


class AI3D_OT_open_settings(Operator):
    bl_idname = "ai3d.open_settings"
    bl_label = "Open Settings"
    bl_description = "Open the extension preferences page"
    bl_options = {'REGISTER'}

    def execute(self, context: Any) -> set[str]:
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'PREFERENCES':
                    area.spaces.active.context = 'ADDONS'
                    area.tag_redraw()
                    return {'FINISHED'}
        try:
            bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
        except Exception:
            self.report({'INFO'}, "Open Edit → Preferences → Add-ons and select AI 3D Object Generator.")
        return {'FINISHED'}


class AI3D_OT_open_asset_folder(Operator):
    bl_idname = "ai3d.open_asset_folder"
    bl_label = "Open Asset Folder"
    bl_description = "Open the generated asset cache directory"
    bl_options = {'REGISTER'}

    def execute(self, context: Any) -> set[str]:
        path = Path(props_path(context)).parent
        path.mkdir(parents=True, exist_ok=True)
        try:
            if os.name == "nt":
                os.startfile(str(path))  # type: ignore[attr-defined]
            else:
                import subprocess

                subprocess.Popen(["open", str(path)], close_fds=True)
        except Exception as exc:
            self.report({'ERROR'}, f"Could not open folder: {exc}")
            return {'CANCELLED'}
        return {'FINISHED'}


class AI3D_OT_delete_generated(Operator):
    bl_idname = "ai3d.delete_generated"
    bl_label = "Delete Generated Objects"
    bl_description = "Delete only objects tagged by this extension"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Any) -> set[str]:
        from ..core.constants import GENERATED_COLLECTION_NAME

        collection = bpy.data.collections.get(GENERATED_COLLECTION_NAME)
        if collection is None:
            return {'FINISHED'}
        for obj in list(collection.all_objects):
            if obj.get("ai3d_generated", False):
                bpy.data.objects.remove(obj, do_unlink=True)
        return {'FINISHED'}


def props_path(context: Any) -> str:
    return _history_path(_scene_props(context))


def _on_update(context: Any, snapshot: JobSnapshot) -> None:
    props = _scene_props(context)
    props.status = snapshot.message
    props.progress = snapshot.progress
    props.current_job_id = snapshot.job_id
    props.error_message = snapshot.error
    props.output_path = snapshot.output_path
    if context.area:
        context.area.tag_redraw()


def _on_finished(context: Any, result: Any, snapshot: JobSnapshot) -> None:
    props = _scene_props(context)
    props.status = result.message or snapshot.message
    props.progress = 1.0 if result.status == STATUS_COMPLETED else props.progress
    props.current_job_id = result.job_id
    props.error_message = result.error
    props.output_path = result.file_path or props.output_path
    props.timer_running = False
    if result.status == STATUS_COMPLETED:
        if COORDINATOR.request:
            request = GenerationRequest(
                prompt=COORDINATOR.request.get("prompt", ""),
                negative_prompt=COORDINATOR.request.get("negative_prompt", ""),
                quality=COORDINATOR.request.get("quality", "standard"),
                output_format=COORDINATOR.request.get("output_format", "glb"),
                style=COORDINATOR.request.get("style", "realistic"),
                polygon_target=COORDINATOR.request.get("polygon_target", 50000),
                generate_materials=COORDINATOR.request.get("generate_materials", True),
                generate_textures=COORDINATOR.request.get("generate_textures", True),
            )
            _add_history(context, result.job_id, request, result.file_path, result.status)
        try:
            _import_downloaded(context, result.file_path)
        except (AI3DError, ImportError_, ValueError) as exc:
            props.status = "Asset downloaded, but Blender import failed."
            props.error_message = exc.user_message() if isinstance(exc, (AI3DError, ImportError_)) else str(exc)
    else:
        if COORDINATOR.request:
            request = GenerationRequest(
                prompt=COORDINATOR.request.get("prompt", ""),
                negative_prompt=COORDINATOR.request.get("negative_prompt", ""),
                quality=COORDINATOR.request.get("quality", "standard"),
                output_format=COORDINATOR.request.get("output_format", "glb"),
            )
            _add_history(context, result.job_id, request, "", result.status, result.error)
    if COORDINATOR.timer is not None:
        try:
            bpy.app.timers.unregister(COORDINATOR.timer)
        except Exception:
            pass
        COORDINATOR.timer = None
    COORDINATOR.job = None


def _result_from_snapshot(job: JobManager) -> Any:
    from ..core.models import GenerationResult

    return GenerationResult(job_id=job.snapshot.job_id, status=job.snapshot.state, message=job.snapshot.message, error=job.snapshot.error, file_path=job.snapshot.output_path)


def _timer_callback() -> Optional[float]:
    if COORDINATOR.job is None:
        return None
    COORDINATOR.job.tick()
    if COORDINATOR.job is None or COORDINATOR.job.snapshot.is_finished:
        return None
    return 1.0


classes = (
    AI3D_OT_generate,
    AI3D_OT_cancel,
    AI3D_OT_retry,
    AI3D_OT_import,
    AI3D_OT_delete_history_entry,
    AI3D_OT_clear_history,
    AI3D_OT_open_settings,
    AI3D_OT_open_asset_folder,
    AI3D_OT_delete_generated,
)


def register() -> None:
    for cls in classes:
        if not getattr(cls, "is_registered", False):
            bpy.utils.register_class(cls)


def _safe_unregister_class(cls: Any) -> None:
    if getattr(cls, "is_registered", False):
        bpy.utils.unregister_class(cls)


def unregister() -> None:
    if COORDINATOR.timer is not None:
        try:
            bpy.app.timers.unregister(COORDINATOR.timer)
        except Exception:
            pass
        COORDINATOR.timer = None
    COORDINATOR.job = None
    for cls in reversed(classes):
        _safe_unregister_class(cls)
