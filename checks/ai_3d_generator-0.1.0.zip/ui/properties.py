"""Blender extension property groups and dynamic enum callbacks."""
from __future__ import annotations

from typing import Any

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup

from ..core.constants import SUPPORTED_FORMATS
from ..providers.registry import PROVIDERS


def _provider_items(self: Any, context: Any) -> list[tuple[str, str, str]]:
    return [(key, cls.display_name, key) for key, cls in PROVIDERS.items()]


def _model_items(self: Any, context: Any) -> list[tuple[str, str, str]]:
    try:
        from ..providers.registry import get_provider_class
        provider = get_provider_class(self.provider)(_provider_config_from_props(self))
        return [(model, model, model) for model in provider.models()]
    except Exception:
        return [("default", "Default", "Provider default model")]


def _provider_config_from_props(props: Any) -> Any:
    from ..core.models import ProviderConfig

    return ProviderConfig(
        base_url=props.api_base_url,
        api_key=props.api_key,
        api_key_env=props.api_key_env,
        requires_api_key=props.requires_api_key,
        model=props.model,
        timeout=props.timeout,
        generate_path=props.generate_path,
        status_path=props.status_path_template,
        cancel_path=props.cancel_path_template,
        auth_header=props.auth_header,
        auth_prefix=props.auth_prefix,
        headers=_parse_headers(props.custom_headers),
        request_payload=_parse_json(props.request_payload),
        download_host_allowlist=[part.strip().lower() for part in str(getattr(props, "download_host_allowlist", "")).split(",") if part.strip()],
        job_id_path=props.job_id_path,
        status_path_value=props.status_path_value,
        progress_path=props.progress_path,
        output_url_path=props.output_url_path,
        error_path=props.error_path,
        max_asset_size_mb=props.max_asset_size_mb,
        poll_interval=props.poll_interval,
        job_timeout=props.job_timeout,
    )


def _parse_headers(value: str) -> dict[str, str]:
    import json

    if not str(value or "").strip():
        return {}
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return {}
    return {str(key): str(item) for key, item in parsed.items()} if isinstance(parsed, dict) else {}


def _parse_json(value: str) -> dict[str, Any]:
    import json

    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


class AI3D_GeneratedHistoryItem(PropertyGroup):
    job_id: StringProperty(name="Job ID")
    negative_prompt: StringProperty(name="Negative Prompt", default="")
    timestamp: StringProperty(name="Timestamp")
    prompt: StringProperty(name="Prompt")
    provider: StringProperty(name="Provider")
    model: StringProperty(name="Model")
    quality: StringProperty(name="Quality")
    output_format: StringProperty(name="Format", default="glb")
    file_path: StringProperty(name="File")
    status: StringProperty(name="Status")
    error: StringProperty(name="Error")


class AI3D_Settings(PropertyGroup):
    """Transient UI state stored on Scene and mirrored by Preferences."""

    prompt: StringProperty(name="Prompt", default="", description="Describe the 3D object to generate")
    provider: StringProperty(name="Provider", default="mock", description="Registered provider identifier")
    model: StringProperty(name="Model", default="default", description="Provider model identifier")
    negative_prompt: StringProperty(name="Negative Prompt", default="")
    quality: EnumProperty(name="Quality", items=[("draft", "Draft", "Fast preview"), ("standard", "Standard", "Balanced quality"), ("high", "High", "Highest supported quality")])
    output_format: EnumProperty(name="Output Format", items=[(fmt, fmt.upper(), f"Import {fmt.upper()}") for fmt in SUPPORTED_FORMATS])
    style: StringProperty(name="Style", default="realistic")
    polygon_target: IntProperty(name="Polygon Target", default=50000, min=100, max=10000000)
    generate_materials: BoolProperty(name="Generate Materials", default=True)
    generate_textures: BoolProperty(name="Generate Textures", default=True)
    auto_center: BoolProperty(name="Auto Center", default=True)
    auto_scale: BoolProperty(name="Auto Scale", default=True)
    smooth_shading: BoolProperty(name="Smooth Shading", default=False)
    generate_collision_mesh: BoolProperty(name="Generate Collision Mesh", default=False)
    delete_previous: BoolProperty(name="Delete Previous Generated Object", default=False)
    auto_import: BoolProperty(name="Import Asset", default=True)
    location_mode: EnumProperty(name="Location", items=[("CURSOR", "3D Cursor", "Place at the 3D cursor"), ("ORIGIN", "World Origin", "Place at the world origin"), ("COLLECTION", "Active Collection", "Place in the active collection")])
    status: StringProperty(name="Status", default="Ready")
    error_message: StringProperty(name="Error", default="")
    progress: FloatProperty(name="Progress", default=0.0, min=0.0, max=1.0)
    current_job_id: StringProperty(name="Current Job ID", default="")
    output_path: StringProperty(name="Output Path", default="")
    timer_running: BoolProperty(name="Timer Running", default=False)
    history: CollectionProperty(type=AI3D_GeneratedHistoryItem)
    history_index: IntProperty(name="History Index", default=-1)
    api_base_url: StringProperty(name="API Base URL", default="http://127.0.0.1:8000")
    api_key: StringProperty(name="API Key", default="", subtype='PASSWORD')
    api_key_env: StringProperty(name="API Key Environment Variable", default="")
    requires_api_key: BoolProperty(name="Requires API Key", default=False)
    generate_path: StringProperty(name="Generate Endpoint", default="/generate")
    status_path_template: StringProperty(name="Status Endpoint", default="/jobs/{job_id}")
    cancel_path_template: StringProperty(name="Cancel Endpoint", default="/jobs/{job_id}/cancel")
    auth_header: StringProperty(name="Auth Header", default="Authorization")
    auth_prefix: StringProperty(name="Auth Prefix", default="Bearer ")
    custom_headers: StringProperty(name="Custom Headers JSON", default="{}")
    request_payload: StringProperty(name="Request Payload JSON", default="{}")
    download_host_allowlist: StringProperty(name="Download Host Allowlist", default="")
    job_id_path: StringProperty(name="Job ID Path", default="id")
    status_path_value: StringProperty(name="Status Path", default="status")
    progress_path: StringProperty(name="Progress Path", default="progress")
    output_url_path: StringProperty(name="Output URL Path", default="download_url")
    error_path: StringProperty(name="Error Path", default="error")
    max_asset_size_mb: IntProperty(name="Max Asset Size MB", default=512, min=1, max=4096)
    poll_interval: FloatProperty(name="Polling Interval", default=2.0, min=0.5, max=120.0)
    timeout: FloatProperty(name="Request Timeout", default=60.0, min=1.0, max=600.0)
    job_timeout: FloatProperty(name="Job Timeout", default=900.0, min=10.0, max=86400.0)
    cache_dir: StringProperty(name="Cache Directory", default="", subtype='DIR_PATH')
    debug_mode: BoolProperty(name="Debug Mode", default=False)


classes = (AI3D_GeneratedHistoryItem, AI3D_Settings)
_REGISTERED = False


def register() -> None:
    global _REGISTERED
    for cls in classes:
        if not getattr(cls, "is_registered", False):
            bpy.utils.register_class(cls)
    if not hasattr(bpy.types.Scene, "ai3d"):
        bpy.types.Scene.ai3d = PointerProperty(type=AI3D_Settings)
    _REGISTERED = True


def _safe_unregister_class(cls: Any) -> None:
    if getattr(cls, "is_registered", False):
        bpy.utils.unregister_class(cls)


def unregister() -> None:
    global _REGISTERED
    if not _REGISTERED:
        return
    _REGISTERED = False
    if hasattr(bpy.types.Scene, "ai3d"):
        del bpy.types.Scene.ai3d
    for cls in reversed(classes):
        _safe_unregister_class(cls)
