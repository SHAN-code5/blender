"""Blender 3D View sidebar panel and collapsible sections."""
from __future__ import annotations

from typing import Any

import bpy
from bpy.types import Panel


class _Section:
    """Small helper for consistent Blender panel sections."""

    @staticmethod
    def box(layout: bpy.types.UILayout, title: str, open_default: bool = True):
        row = layout.row()
        row.prop(layout, "show_expanded", text=title, icon='TRIA_DOWN' if open_default else 'TRIA_RIGHT', emboss=False)
        return layout if row else layout


class AI3D_PT_main(Panel):
    bl_idname = "AI3D_PT_main"
    bl_label = "AI 3D Object Generator"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "AI 3D"

    def draw(self, context: bpy.types.Context) -> None:
        layout = self.layout
        props = context.scene.ai3d
        box = layout.box()
        box.label(text="Generate", icon='LIGHT')
        box.prop(props, "prompt", text="Prompt")
        row = box.row(align=True)
        row.prop(props, "provider", text="Provider")
        row.prop(props, "model", text="Model")
        row = box.row(align=True)
        row.prop(props, "quality", text="Quality")
        row.prop(props, "output_format", text="Format")
        row = box.row(align=True)
        row.prop(props, "negative_prompt", text="Negative")
        row.prop(props, "style", text="Style")
        row = box.row(align=True)
        row.prop(props, "polygon_target", text="Polygon Target")
        if not props.timer_running:
            box.operator("ai3d.generate", text="GENERATE 3D", icon='SHADERFX')
        else:
            box.operator("ai3d.cancel", text="CANCEL", icon='CANCEL')

        box = layout.box()
        box.label(text="Status", icon='INFO')
        box.label(text=props.status)
        box.progress(factor=props.progress, text=f"{props.progress * 100:.0f}%")
        if props.error_message:
            box.label(text=props.error_message, icon='ERROR')

        box = layout.box()
        box.label(text="Quality & Output", icon='MOD_SMOOTH')
        box.prop(props, "generate_materials")
        box.prop(props, "generate_textures")
        box.prop(props, "auto_center")
        box.prop(props, "auto_scale")
        box.prop(props, "smooth_shading")
        box.prop(props, "generate_collision_mesh")
        box.prop(props, "delete_previous")
        box.prop(props, "location_mode", text="Place At")

        box = layout.box()
        box.label(text="Provider", icon='URL')
        box.prop(props, "api_base_url", text="API URL")
        box.prop(props, "api_key", text="API Key")
        box.prop(props, "api_key_env", text="Key Env Var")
        box.operator("ai3d.open_settings", text="SETTINGS", icon='PREFERENCES')
        box.operator("ai3d.open_asset_folder", text="OPEN ASSET FOLDER", icon='FILE_FOLDER')

        box = layout.box()
        box.label(text="History", icon='TIME')
        for index, item in enumerate(props.history):
            row = box.row(align=True)
            row.label(text=f"{index + 1}. {item.prompt[:28]}" + ("…" if len(item.prompt) > 28 else ""))
            if item.file_path:
                op = row.operator("ai3d.import", text="IMPORT", icon='IMPORT')
                op.filepath = item.file_path
            op = row.operator("ai3d.retry", text="RETRY", icon='FILE_REFRESH')
            op.index = index
            if len(props.history) > 1:
                op = row.operator("ai3d.delete_history_entry", text="", icon='X')
                op.index = index
        if props.history:
            box.operator("ai3d.clear_history", text="CLEAR HISTORY", icon='TRASH')
        if props.output_path:
            box.operator("ai3d.import", text="IMPORT LAST ASSET", icon='IMPORT').filepath = props.output_path
        box.operator("ai3d.delete_generated", text="DELETE GENERATED OBJECTS", icon='TRASH')


classes = (AI3D_PT_main,)


def register() -> None:
    for cls in classes:
        if not getattr(cls, "is_registered", False):
            bpy.utils.register_class(cls)


def _safe_unregister_class(cls: Any) -> None:
    if getattr(cls, "is_registered", False):
        bpy.utils.unregister_class(cls)


def unregister() -> None:
    for cls in reversed(classes):
        _safe_unregister_class(cls)
