"""AI 3D Object Generator Blender extension entry point."""
from __future__ import annotations

import importlib
import logging

from .core.constants import EXTENSION_NAME, VERSION

# Import registration modules once here. All classes are registered in
# dependency order: properties/preferences, then operators, then panels.
_MODULES = (
    ".ui.properties",
    ".ui.preferences",
    ".ui.operators",
    ".ui.panels",
)

logger = logging.getLogger("ai_3d_generator")


def register() -> None:
    """Register the extension with Blender."""
    modules = [importlib.import_module(name, __package__) for name in _MODULES]
    properties = modules[0]
    preferences = modules[1]
    operators = modules[2]
    panels = modules[3]
    properties.register()
    preferences.register()
    try:
        operators.register()
        panels.register()
    except Exception:
        if getattr(panels, "AI3D_PT_main", None) is not None and getattr(panels.AI3D_PT_main, "is_registered", False):
            panels.unregister()
        if getattr(operators, "AI3D_OT_generate", None) is not None and getattr(operators.AI3D_OT_generate, "is_registered", False):
            operators.unregister()
        preferences.unregister()
        properties.unregister()
        raise


def unregister() -> None:
    """Unregister the extension cleanly, tolerating partial registration."""
    for name in reversed(_MODULES):
        try:
            module = importlib.import_module(name, __package__)
            module.unregister()
        except (ImportError, AttributeError):
            pass
        except RuntimeError:
            logger.exception("Could not unregister %s", name)


if __name__ == "__main__":
    print(f"{EXTENSION_NAME} {VERSION}")
