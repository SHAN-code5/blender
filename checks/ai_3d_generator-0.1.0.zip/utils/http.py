"""Standard-library HTTP client with bounded streaming and safe errors.

Requests are intentionally short-lived and run from Blender's timer callback
rather than from the UI draw handler. This keeps the main thread responsive
between bounded requests while avoiding a background-thread UI race.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

from ..core.errors import AuthenticationError, NetworkError, ProviderResponseError
from .validation import parse_json_response, validate_http_url


@dataclass
class HttpResponse:
    status: int
    headers: Mapping[str, str]
    body: bytes


class HttpClient:
    """Dependency-free JSON/bytes HTTP client with a bounded request size."""

    def __init__(self, timeout: float = 60.0, user_agent: str = "AI3DGenerator/0.1") -> None:
        self.timeout = max(0.1, float(timeout))
        self.user_agent = user_agent

    def request(
        self,
        method: str,
        url: str,
        *,
        headers: Optional[Mapping[str, str]] = None,
        json_body: Optional[Any] = None,
        timeout: Optional[float] = None,
        max_bytes: int = 8 * 1024 * 1024,
    ) -> HttpResponse:
        """Make a bounded HTTP request and return response bytes."""
        target = validate_http_url(url, "HTTP URL")
        request_headers = {"User-Agent": self.user_agent, "Accept": "application/json"}
        if headers:
            request_headers.update({str(key): str(value) for key, value in headers.items()})
        data = None
        if json_body is not None:
            data = json.dumps(json_body, separators=(",", ":")).encode("utf-8")
            request_headers["Content-Type"] = "application/json"
        request = urllib.request.Request(target, data=data, headers=request_headers, method=method.upper())
        try:
            with urllib.request.urlopen(request, timeout=timeout or self.timeout) as response:
                body = response.read(max_bytes + 1)
                if len(body) > max_bytes:
                    raise ProviderResponseError("Provider response is larger than the configured limit.")
                return HttpResponse(int(response.status), dict(response.headers.items()), body)
        except urllib.error.HTTPError as exc:
            body = b""
            try:
                body = exc.read(min(64 * 1024, max_bytes))
            except Exception:
                pass
            if exc.code in (401, 403):
                raise AuthenticationError("The provider rejected the API key or permissions.", detail=f"HTTP {exc.code}") from exc
            if exc.code == 429:
                raise NetworkError("The provider rate limit was reached. Try again later.", detail=f"HTTP {exc.code}") from exc
            if 500 <= exc.code <= 599:
                raise NetworkError("The provider is temporarily unavailable.", detail=f"HTTP {exc.code}") from exc
            raise ProviderResponseError("The provider rejected the request.", detail=f"HTTP {exc.code}") from exc
        except urllib.error.URLError as exc:
            reason = getattr(exc, "reason", exc)
            raise NetworkError("Could not reach the provider. Check the URL and your internet connection.", detail=str(reason)) from exc
        except TimeoutError as exc:
            raise NetworkError("The provider request timed out.", detail="timeout") from exc

    def request_json(self, method: str, url: str, **kwargs: Any) -> Tuple[Dict[str, Any], HttpResponse]:
        """Make a request and decode an object response."""
        response = self.request(method, url, **kwargs)
        return parse_json_response(response.body, response.headers.get("Content-Type", "")), response
