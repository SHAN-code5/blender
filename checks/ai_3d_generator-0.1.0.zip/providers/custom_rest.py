"""Configurable generic REST provider.

The adapter is intentionally honest: users map their provider's actual JSON
shape through preferences. No provider is claimed to work without configuring
its endpoints and response paths.
"""
from __future__ import annotations

import os
from typing import Any, Dict, Optional

from ..core.errors import AuthenticationError, ConfigurationError, ProviderResponseError
from ..core.models import JobHandle, JobStatus, ProviderConfig
from ..utils.paths import endpoint_for_job, join_endpoint
from ..utils.validation import extract_error, extract_job_id, extract_output_url, get_by_path, normalize_status, validate_http_url
from .base import Base3DProvider


class CustomRESTProvider(Base3DProvider):
    """REST adapter for APIs following a configurable async job protocol."""

    identifier = "custom_api"
    display_name = "Custom REST API"
    requires_api_key = False

    def _resolved_api_key(self) -> str:
        if self.config.api_key:
            return self.config.api_key
        if self.config.api_key_env:
            return os.environ.get(self.config.api_key_env, "").strip()
        return ""

    def _headers(self) -> Dict[str, str]:
        headers = {str(key): str(value) for key, value in self.config.headers.items() if str(key).strip()}
        key = self._resolved_api_key()
        if key:
            if not self.config.auth_header.strip():
                raise ConfigurationError("Authentication header cannot be empty.")
            headers[self.config.auth_header] = f"{self.config.auth_prefix}{key}"
        return headers

    def validate_credentials(self) -> None:
        super().validate_credentials()
        if not self.config.base_url:
            raise ConfigurationError("API Base URL is required for the custom provider.")
        validate_http_url(self.config.base_url, "API Base URL")
        if self.config.requires_api_key:
            self._require_key()

    def _require_key(self) -> None:
        if not self._resolved_api_key():
            raise AuthenticationError("Enter an API key or set the configured environment variable.")

    def create_generation_job(self, request: Dict[str, Any]) -> JobHandle:
        payload = dict(self.config.request_payload)
        payload.update(request)
        payload["model"] = self.config.model
        url = join_endpoint(self.config.base_url, self.config.generate_path)
        data, _ = self.client.request_json("POST", url, headers=self._headers(), json_body=payload, timeout=self.config.timeout)
        job_id = extract_job_id(data, self.config.job_id_path)
        return JobHandle(job_id=job_id, provider=self.identifier, raw=data)

    def get_job_status(self, job_id: str, elapsed_seconds: float = 0.0) -> JobStatus:
        url = endpoint_for_job(self.config.status_path, self.config.base_url, job_id)
        data, _ = self.client.request_json("GET", url, headers=self._headers(), timeout=self.config.timeout)
        state = normalize_status(get_by_path(data, self.config.status_path_value))
        if state == "unknown":
            raise ProviderResponseError("Provider returned an unknown job status.")
        progress = _as_progress(get_by_path(data, self.config.progress_path))
        message = str(get_by_path(data, "message", "") or "")
        error = extract_error(data, self.config.error_path)
        output_url = None
        if state == "completed":
            try:
                output_url = extract_output_url(data, self.config.output_url_path)
            except ValidationError as exc:
                raise ProviderResponseError(exc.user_message(), detail=exc.detail) from exc
        return JobStatus(state=state, progress=progress, message=message, output_url=output_url, error=error, raw=data)

    def cancel_job(self, job_id: str) -> None:
        url = endpoint_for_job(self.config.cancel_path, self.config.base_url, job_id)
        self.client.request("POST", url, headers=self._headers(), timeout=self.config.timeout)

    def download_asset(self, url: str, destination: Any) -> str:
        response = self.client.request("GET", url, headers=self._headers(), timeout=self.config.timeout, max_bytes=self.config.max_asset_size_mb * 1024 * 1024)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(".partial-" + destination.name)
        temporary.write_bytes(response.body)
        temporary.replace(destination)
        return str(destination)

    def models(self) -> list[str]:
        return [self.config.model or self.default_model]


def _as_progress(value: Any) -> float:
    try:
        number = float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0
    if number > 1.0:
        number /= 100.0
    return max(0.0, min(1.0, number))
