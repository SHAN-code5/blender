"""Local HTTP provider using the same contract as CustomRESTProvider."""
from __future__ import annotations

from .custom_rest import CustomRESTProvider


class LocalProvider(CustomRESTProvider):
    """Adapter for a local text-to-3D service.

    Configure its base URL and endpoint mappings in Preferences. It is not a
    built-in server and therefore does not claim to generate without one.
    """

    identifier = "local_api"
    display_name = "Local API"
